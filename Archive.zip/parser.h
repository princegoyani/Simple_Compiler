#ifndef __PARSER_H__
#define __PARSER_H__

#include <vector>
#include <string>
#include <sstream> // Required for istringstream
#include <set> // Required for std::set
#include "lexer.h"

struct poly_header_t {
    Token name;
    std::vector<std::string> id_list;
};

struct poly_body_t {
    std::string body;
};

struct poly_decl_t {
    poly_header_t header;
    poly_body_t body;
};

class Parser {
  public:
    void ConsumeAllInput();
    int evaluate_polynomial(const std::string& body, const std::vector<int>& args);

  private:
    LexicalAnalyzer lexer;
    void syntax_error();
    Token expect(TokenType expected_type);
    
    // Parsing functions
    void parse_program();
    void parse_tasks_section();
    void parse_poly_section();
    void parse_poly_decl_list();
    poly_decl_t parse_poly_decl();
    poly_header_t parse_poly_header();
    std::vector<std::string> parse_id_list();
    poly_body_t parse_poly_body(poly_header_t);
    void parse_execute_section();
    void parse_statement();
    void parse_input_statement();
    void parse_output_statement();
    void parse_assignment_statement();
    int parse_poly_evaluation();
    int parse_argument();
    void parse_argument_list();
    void parse_inputs_section();
    void execute_program();
    
    // Additional helper functions
    bool is_valid_variable(const std::string& var);
};

#endif // __PARSER_H__
