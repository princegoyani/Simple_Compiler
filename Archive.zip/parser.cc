#include <iostream>
#include <vector>
#include <map>
#include "parser.h"

using namespace std;

// Global data structures
vector<poly_decl_t> polynomials;
map<string, int> symbol_table;
vector<int> inputs;
int next_available = 0;
map<string, int> variable_values;
map<string, bool> initialized_variables;
vector<string> execution_order;
static std::map<std::string, int> poly_first_occurrence;

void Parser::syntax_error() {
    cout << "SYNTAX ERROR !!!!!&%!!\n";
    exit(1);
}

Token Parser::expect(TokenType expected_type) {
    Token t = lexer.GetToken();
    if (t.token_type != expected_type)
        syntax_error();
    return t;
}

void Parser::ConsumeAllInput() {
    parse_program();
    expect(END_OF_FILE);
    execute_program();
}

void Parser::parse_program() {
    parse_tasks_section();
    parse_poly_section();
    parse_execute_section();
    parse_inputs_section();
}

int Parser::evaluate_polynomial(const std::string& body, const std::vector<int>& args) {
    int result = 0;
    int x = args.empty() ? 0 : args[0]; // Assume one variable for now

    std::istringstream ss(body);
    std::string token;
    while (ss >> token) {
        if (token == "^") {
            int exponent;
            ss >> exponent;
            result = pow(x, exponent);
        } else if (token == "+") {
            continue;
        } else {
            try {
                result += std::stoi(token);
            } catch (...) {
                result += x;
            }
        }
    }
    return result;
}



void Parser::parse_tasks_section() {
    expect(TASKS);
    while (lexer.peek(1).token_type == NUM)
        expect(NUM);
}

void Parser::parse_poly_section() {
    expect(POLY);
    parse_poly_decl_list();
}

void Parser::parse_poly_decl_list() {
    // Static map to track first occurrences of each polynomial name
    static std::map<std::string, int> poly_first_occurrence;
    static std::vector<int> duplicate_lines;

    // Parse the current polynomial declaration
    poly_decl_t decl = parse_poly_decl();
    std::string poly_name = decl.header.name.lexeme;
    int line_number = decl.header.name.line_no;

    // Check if polynomial name already exists
    if (poly_first_occurrence.find(poly_name) != poly_first_occurrence.end()) {
        // Add all occurrences of duplicates
        duplicate_lines.push_back(line_number);
    } else {
        // Store the first occurrence of this polynomial name
        poly_first_occurrence[poly_name] = line_number;
    }

    // Store the polynomial in the global list
    polynomials.push_back(decl);

    // Continue parsing if more polynomial declarations exist
    if (lexer.peek(1).token_type == ID) {
        parse_poly_decl_list();
     }
    else if (lexer.peek(1).token_type == EXECUTE) {
        if (!duplicate_lines.empty()) {
            std::cout << "Semantic Error Code 1:";
            std::sort(duplicate_lines.begin(), duplicate_lines.end());  // Ensure correct order
            
            for (int line : duplicate_lines) {
                std::cout << " " << line;
            }
            std::cout << std::endl;
            exit(1);
        }    
    }
    
}


poly_decl_t Parser::parse_poly_decl() {
    poly_decl_t decl;
    decl.header = parse_poly_header();
    expect(EQUAL);
    decl.body = parse_poly_body(decl.header);
    expect(SEMICOLON);
    return decl;
}

poly_header_t Parser::parse_poly_header() {
    poly_header_t header;
    header.name = expect(ID);
    
    // Continue parsing parameters if present
    Token t = lexer.peek(1);
    if (t.token_type == LPAREN) {
        expect(LPAREN);
        header.id_list = parse_id_list();
        expect(RPAREN);
    } else {
        header.id_list.push_back("x");
    }

    return header;
}


vector<string> Parser::parse_id_list() {
    vector<string> id_list;
    id_list.push_back(expect(ID).lexeme);
    
    while (lexer.peek(1).token_type == COMMA) {
        expect(COMMA);
        id_list.push_back(expect(ID).lexeme);
    }
    return id_list;
}

poly_body_t Parser::parse_poly_body(poly_header_t header) {
    poly_body_t body;
    static std::vector<int> error_lines;
    
    while (lexer.peek(1).token_type != SEMICOLON) {
        Token t = lexer.GetToken();
        body.body += " " + t.lexeme;

        // Check if variable name is valid
        
            if (std::find(header.id_list.begin(), header.id_list.end(), t.lexeme) == header.id_list.end() 
                && t.token_type == ID) {
                error_lines.push_back(t.line_no);
        }        
    }


    if (!error_lines.empty() && lexer.peek(2).token_type == EXECUTE) {
        std::sort(error_lines.begin(), error_lines.end());
        std::cout << "Semantic Error Code 2:";
        for (int line : error_lines) {
            std::cout << " " << line;
        }
        cout << endl;
        exit(1);
    }

    return body;
}



void Parser::parse_execute_section() {
    expect(EXECUTE);
    while (lexer.peek(1).token_type != INPUTS)
        parse_statement();
}

void Parser::parse_statement() {
    Token t = lexer.peek(1);
    if (t.token_type == INPUT)
        parse_input_statement();
    else if (t.token_type == OUTPUT)
        parse_output_statement();
    else if (t.token_type == ID)
        parse_assignment_statement();
    else
        syntax_error();
}

void Parser::parse_input_statement() {
    expect(INPUT);
    Token var = expect(ID);
    
    if (symbol_table.find(var.lexeme) == symbol_table.end()) {
        symbol_table[var.lexeme] = next_available++;
    }

    expect(SEMICOLON);

    if (!inputs.empty()) {
        variable_values[var.lexeme] = inputs.front();
        inputs.erase(inputs.begin());
    } else {
        variable_values[var.lexeme] = 0;
    }
}


void Parser::parse_output_statement() {
    expect(OUTPUT);
    Token var = expect(ID);
    expect(SEMICOLON);
    // if (variable_values.find(var.lexeme) != variable_values.end()) {
    //     cout << variable_values[var.lexeme] << endl;
    // } else {
    //     cout << "0" << endl;
    // }
}

void Parser::parse_assignment_statement() {
    Token var = expect(ID);
    expect(EQUAL);

    // Ensure variable exists in the symbol table before assignment
    if (symbol_table.find(var.lexeme) == symbol_table.end()) {
        symbol_table[var.lexeme] = next_available++;
    }

    int value = parse_poly_evaluation();
    variable_values[var.lexeme] = value;
    initialized_variables[var.lexeme] = true; // Mark as initialized

    expect(SEMICOLON);
}


int Parser::parse_poly_evaluation() {
    Token poly = expect(ID);
    expect(LPAREN);

    std::vector<int> args;
    args.push_back(parse_argument());

    while (lexer.peek(1).token_type == COMMA) {
        expect(COMMA);
        args.push_back(parse_argument());
    }
    expect(RPAREN);

    // Look up polynomial and evaluate
    for (const auto& p : polynomials) {
        if (p.header.name.lexeme == poly.lexeme) {
            return evaluate_polynomial(p.body.body, args);
        }
    }

    return 0; // Default return if polynomial not found
}


void Parser::parse_argument_list() {
    std::vector<std::string> args;
    args.push_back(expect(ID).lexeme);

    while (lexer.peek(1).token_type == COMMA) {
        expect(COMMA);
        args.push_back(expect(ID).lexeme);
    }

    // Verify argument count matches declaration
    Token poly = lexer.peek(-2);
    for (const auto& p : polynomials) {
        if (p.header.name.lexeme == poly.lexeme) {
            if (args.size() != p.header.id_list.size()) {
                std::cout << "Semantic Error Code 4: " << poly.line_no << std::endl;
                exit(1);
            }
        }
    }
}


int Parser::parse_argument() {
    Token t = lexer.GetToken();
    if (t.token_type == NUM) return stoi(t.lexeme);
    if (t.token_type == ID) return variable_values[t.lexeme];
    syntax_error();
    return 0;
}

void Parser::parse_inputs_section() {
    expect(INPUTS);
    while (lexer.peek(1).token_type == NUM)
        inputs.push_back(stoi(expect(NUM).lexeme));
}

void Parser::execute_program() {
    std::set<std::string> used_variables;
    for (const auto& stmt : execution_order) {
        if (stmt.find("=") != std::string::npos) {
            std::string var = stmt.substr(0, stmt.find("="));
            used_variables.insert(var);
        }
    }

    std::vector<int> useless_lines;
    for (const auto& var : variable_values) {
        if (used_variables.find(var.first) == used_variables.end()) {
            useless_lines.push_back(symbol_table[var.first]);
        }
    }

    if (!useless_lines.empty()) {
        std::sort(useless_lines.begin(), useless_lines.end());
        std::cout << "Warning Code 2:";
        for (int line : useless_lines) {
            std::cout << " " << line;
        }
        std::cout << std::endl;
    }
}


int main() {
    Parser parser;
    parser.ConsumeAllInput();
    return 0;
}
